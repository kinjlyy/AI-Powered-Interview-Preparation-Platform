# InterviewPrep Authentication API

Node.js + Express + MongoDB backend that powers the login/signup pages in the `frontend/` app.

## Features

- User registration and login with hashed passwords (`bcryptjs`)
- JWT auth with configurable expiry
- Protected `/api/auth/me` endpoint for profile data
- CORS configured for the frontend origin
- MongoDB connection via Mongoose

## Folder Structure

```
backend/
  src/
    config/db.js          # Mongo connection helper
    controllers/          # Request handlers
    middleware/auth.js    # JWT gatekeeper
    models/User.js        # Mongoose schema
    routes/authRoutes.js  # /api/auth endpoints
    utils/                # Helpers (JWT + validators)
    server.js             # App entrypoint
  .env.example
  package.json
```

## Prerequisites

- Node.js 18+
- MongoDB URI (local or Atlas)

## Setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env with real secrets + Mongo URI
```

Required environment variables (see `.env.example`):

- `PORT` – server port (defaults to 4000)
- `MONGO_URI` – MongoDB connection string
- `JWT_SECRET` – strong secret for signing tokens
- `JWT_EXPIRES_IN` – token lifetime (e.g. `7d`)
- `FRONTEND_ORIGIN` – e.g. `http://localhost:5173`

## Run

```bash
npm run dev    # nodemon
# or
npm start
```

API endpoints:

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET  /api/auth/me` (requires `Authorization: Bearer <token>`)
- `GET  /api/ping`

## Example Requests

```bash
curl -X POST http://localhost:4000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{ "name": "Ada Lovelace", "email": "ada@example.com", "password": "secret123" }'

curl -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{ "email": "ada@example.com", "password": "secret123" }'

curl http://localhost:4000/api/auth/me \
  -H "Authorization: Bearer <token>"
```

Frontend fetch helper (aligns with `frontend/src/pages/Login.jsx` & `Signup.jsx`):

```js
const API_BASE = 'http://localhost:4000/api/auth';

export const signup = (payload) =>
  fetch(`${API_BASE}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    credentials: 'include',
  }).then(async (res) => {
    if (!res.ok) throw await res.json();
    return res.json();
  });

export const login = (payload) =>
  fetch(`${API_BASE}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    credentials: 'include',
  }).then(async (res) => {
    if (!res.ok) throw await res.json();
    return res.json();
  });
```

Use the returned `{ token, user }` to store the JWT (e.g., in memory or secure storage) and send it as `Authorization: Bearer <token>` when calling protected routes.


