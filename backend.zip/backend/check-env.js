﻿require("dotenv").config();
const fs = require("fs");
const path = require("path");

console.log("cwd ->", process.cwd());

try {
    const envPath = path.resolve(process.cwd(), ".env");
    const raw = fs.readFileSync(envPath, "utf8");
    console.log("---- .env (first 10 lines) ----");
    raw.split(/\r?\n/).slice(0,10).forEach((l,i) => console.log(`${i+1}: ${l}`));
    console.log("---- end .env ----");
} catch (e) {
    console.log(".env read error:", e.message);
}

const uri = process.env.MONGO_URI;
const masked = uri ? uri.replace(/:\/\/([^:]+):([^@]+)@/, "://$1:*****@") : "undefined";

console.log("MONGO_URI ->", masked);
