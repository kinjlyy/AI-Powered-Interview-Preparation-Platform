// src/server.js
// load env *first*
require('dotenv').config();

const path = require('path'); // optional: keep if you use it later
const express = require('express');
const cors = require('cors');

const connectDB = require('./config/db');

const app = express();
const PORT = process.env.PORT || 4000;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'http://localhost:3000';

// Core middleware
app.use(express.json());
app.use(
  cors({
    origin: FRONTEND_ORIGIN,
    credentials: true,
  })
);

// Health check
app.get('/api/ping', (_req, res) => {
  res.json({ ok: true });
});

// Routes
app.use('/api/auth', require('./routes/authRoutes')); // ensure this file exists

const bootstrap = async () => {
  await connectDB();

  app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
  });
};

bootstrap().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

